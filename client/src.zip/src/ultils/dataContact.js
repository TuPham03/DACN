export const text = {
    image: 'https://phongtro123.com/images/support-bg.jpg',
    content: 'Liên hệ với chúng tôi nếu bạn cần hỗ trợ:',
    contacts: [
        {
            text: 'HỖ TRỢ THANH TOÁN',
            phone: 'Điện thoại: 0917686101',
            zalo: 'Zalo: 0917686101'
        },
        {
            text: 'HỖ TRỢ ĐĂNG TIN',
            phone: 'Điện thoại: 0902657123',
            zalo: 'Zalo: 0902657123'
        },
        {
            text: 'HOTLINE 24/7',
            phone: 'Điện thoại: 0917686101',
            zalo: 'Zalo: 0917686101'
        },
    ]
}